﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Referee {//Vai controlar os jogadores em campo 

	public enum Events{
		FOUL,//FALTA
		INJURED,//MACHUCADO
		RED,//CARTAO VERMELHO
		YELLOW,//CARTAO AMARELO

	}
}
