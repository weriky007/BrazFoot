﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coach
{
    public Team myTeam;
    public string coachName;
    public float money;
    public float xp;
    public int age;
    public int carreer;// ANOS DE CARREIRA
    public int wins;
    public int losts;
    public int level;


}
